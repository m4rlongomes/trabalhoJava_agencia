package br.com.agencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgenciaTests {

	@Test
	void contextLoads() {
	}

}
